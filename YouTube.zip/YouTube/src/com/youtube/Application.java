package com.youtube;

import com.youtube.controller.CommentController;
import com.youtube.model.Comment;

public class Application {

	public static void main(String[] args) {

		// 테스트 하는 공간이라 생각하면 됨!
		CommentController commentControl = new CommentController();
		// ..
		// ..
		
		commentControl.addCommment("test1234", "1234", new Comment());
		
		
		
		
		
		
		
		
		
		
		
	}

}

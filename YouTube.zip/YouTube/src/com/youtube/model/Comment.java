package com.youtube.model;

public class Comment {

	private String id;
	private String comment;
	
	private User user;
	
}

package com.youtube.model;

// 모델은 요런 방식으로~
public class Category {

	private String id;
	private String name;
	
}
